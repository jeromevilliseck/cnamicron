<?php
/**
 * Class de type Modèle gérant la table DOCUMENTS
 * 
 * @author Christian Bonhomme
 * @version 1.0
 * @package Sécurité
 */
class MDocuments
{
  /**
   * Connexion à la Base de Données
   * @var object $conn
   */
  private $conn;

  /**
   * Clef primaire de la table USERS et de la table USER_DOC
   * @var int $id
   */
  private $id_user;
  
  /**
   * Clef primaire de la table DOCUMENTS et de la table USER_DOC
   * @var int $id
   */
  private $id_doc;
  
  /**
   * Tableau de récupération d'un tuple ou de gestion de données (insert ou update)
   * @var array $value
   */
  private $value;
  
  /**
   * Constructeur de la class MDocuments
   * @param int identifiant de l'utilisateur
   * @param int identifiant du document
   * @access public
   *        
   * @return none
   */
  public function __construct($_id_user = null, $_id_doc = null)
  {
    // Connexion à la Base de Données
    $this->conn = new PDO(DATABASE, LOGIN, PASSWORD);

    // Instanciation du membre $id_user
    $this->id_user = $_id_user;
    
    // Instanciation du membre $id_doc
    $this->id_doc = $_id_doc;
    
    return;
    
  } // __construct($_id_doc = null, $_id_user = null)
  
  /**
   * Destructeur de la class MDocuments
   * @access public
   *        
   * @return none
   */
  public function __destruct(){}

  /**
   * Modificateur du membre $value
   * @access public
   * @param array tableau des données
   *
   * @return none
   */
  public function SetValue($_value)
  {
    $this->value = $_value;
      
    return;
  
  } // SetValue($_value)

  /**
   * Récupère plusieurs tuples de la table DOCUMENTS
   * @access public
   *
   * @return array un tuple
   */
  public function Select()
  {
    $query = "select ID_DOC,
                     TITRE,
                     TEXTE
              from DOCUMENTS
              where ID_DOC = $this->id_doc";

    $result = $this->conn->prepare($query);

    $result->execute();
      
    return $result->fetch();
        
  } // Select()

  /**
   * Récupère plusieurs tuples de la table DCUMENTS
   * @access public
   *
   * @return array plusieurs tuples
   */
  public function SelectAll()
  {
    $query = 'select ID_DOC,
                     TITRE,
                     TEXTE
              from DOCUMENTS';

    $result = $this->conn->prepare($query);

    $result->execute();
      
    return $result->fetchAll();
  
  } // selectAll()
  
  /**
   * Déclenche une modification des données d'une table
   * @param string type de modification (insert, update ou delete)
   * @access public
   *
   * @return none
   */
  public function Modify($_type)
  {
    switch ($_type)
    {
      case 'insert' : $this->Insert(); break;
      case 'update' : $this->Update(); break;
      case 'delete' : $this->Delete(); break;
    }
    
    return;
       
  } // Modify($_type)
  
  /**
   * Insère les données d'un tuple dans la table PEINTRES
   * @access private
   *
   * @return none
   */
  private function Insert()
  {
    // Insertion des données dans la table DOCUMENTS
    $TITRE = $this->value['TITRE'];
    $TEXTE = $this->value['TEXTE'];
   
    $query = "insert into DOCUMENTS (TITRE, TEXTE)
              values('$TITRE', '$TEXTE')";
  
    $result = $this->conn->prepare($query);

    $result->execute();

    $this->id_doc = $this->conn->lastInsertId();

    // Insertion des données dans la table de liaison USER_DOC
    $query = "insert into USER_DOC (ID_USER, ID_DOC)
              values($this->id_user, $this->id_doc)";
      
    $result = $this->conn->prepare($query);

    $result->execute();
    
    return;

  } // Insert()
  
  /**
   * Insère les données d'un tuple dans la table PEINTRES
   * @access private
   *
   * @return none
   */
  private function Update()
  {
    $TITRE = $this->value['TITRE'];
    $TEXTE = $this->value['TEXTE'];
     
    $query = "update DOCUMENTS
              set TITRE = '$TITRE',
                  TEXTE = '$TEXTE'
              where ID_DOC = $this->id_doc";

    $result = $this->conn->prepare($query);

    $result->execute();
    
    return;
  
  } // Update()
  
  /**
   * Supprime un tuple de la table PEINTRES
   * @access private
   *
   * @return none
   */
  private function Delete()
  {
    // Suppression du document dans la table de liaison USER_DOC
    $query = "delete from USER_DOC
              where ID_DOC = $this->id_doc
              and ID_USER = $this->id_user";
      
    $result = $this->conn->prepare($query);
      
    $result->execute();
      
    // Suppression du document
    $query = "delete from DOCUMENTS
    where ID_DOC = $this->id_doc";
      
    $result = $this->conn->prepare($query);

    $result->execute();
      
    return;
  
  } // Delete()

  /**
   * Récupère plusieurs tuples de la table DOCUMENTS
   * @access public
   *
   * @return array  plusieurs tuples
   */
  public function SelectUserAll()
  {
    $query = "select USER_DOC.ID_DOC,
                     TITRE,
                     TEXTE
              from DOCUMENTS, USER_DOC
              where USER_DOC.ID_DOC = DOCUMENTS.ID_DOC
              and USER_DOC.ID_USER = $this->id_user";

    $result = $this->conn->prepare($query);

    $result->execute();

    return $result->fetchAll();
  
  } // SelectUserAll()
  
} // MDocuments
?>