create table USERS
(ID_USER      int(11)       NOT NULL AUTO_INCREMENT,
 LOGIN        varchar(10)   NOT NULL,
 PASSWORD     varchar(10)   NOT NULL,
 NOM          varchar(100)  NOT NULL,
 PRENOM       varchar(100)  NOT NULL,
 primary key (ID_USER)
);

create table DOCUMENTS
(ID_DOC  int(11)      NOT NULL AUTO_INCREMENT,
 TITRE   varchar(100) NOT NULL,
 TEXTE   varchar(100) NOT NULL,
 primary key (ID_DOC)
);

create table USER_DOC
(ID_USER int(11)  NOT NULL,
 ID_DOC  int(11)  NOT NULL,
 primary key (ID_USER, ID_DOC),
 constraint FK_USER_DOC_1 
   foreign key(ID_USER) references USERS(ID_USER),
 constraint FK_USER_DOC_2 
   foreign key(ID_DOC) references DOCUMENTS(ID_DOC)
);