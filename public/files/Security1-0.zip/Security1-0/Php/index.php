<?php
/**
 * Contrôleur
 * @author Christian Bonhomme
 * @version 1.0
 * @package Sécurité
 */
 
// Inclusion des constantes et des fonctions de l'application
// en particulier l'Autoload
require('../Inc/require.inc.php');

// Récupération de l'identifiant de l'utilisateur
$ID_USER = isset($_REQUEST['ID_USER']) ?  $_REQUEST['ID_USER'] : '';

// Variable de contrôle
$EX = isset($_REQUEST['EX']) ? $_REQUEST['EX'] : 'home';

// Contrôleur
switch($EX)
{
  case 'home'        : home();           break;
  case 'admin'       : admin();          break;
  case 'connect'     : connect();        break;
  case 'deconnect'   : deconnect();      break;
  case 'liste'       : liste();          break;
  case 'doc'         : doc();            break;
  case 'form_insert' : form('insert');   break;
  case 'form_update' : form('update');   break;
  case 'insert'      : modify('insert'); break;
  case 'update'      : modify('update'); break;
  case 'delete'      : modify('delete'); break;
  default            : home();
}

// Mise en page
require('../View/layout.view.php');

/**
 * Affichage de la page d'accueil
 *
 * @return none
 */
function home()
{
  global $content;
  $content['title'] = 'Accueil';
  $content['class'] = 'VHtml';
  $content['method'] = 'showHtml';
  $content['arg'] = '../Html/home.html';
  
  return;
  
} // home()

/**
 * Affichage du formulaire de connexion
 *
 * @return none
 */
function admin()
{
  global $content;
  $content['title'] = 'Connexion';
  $content['class'] = 'VHtml';
  $content['method'] = 'showHtml';
  $content['arg'] = '../Html/form_connect.html';
    
  return;

} // admin()

/**
 * Vérification de la connexion
 *
 * @return none
 */
function connect()
{
  $musers = new MUsers();
  $value = $musers->VerifUser($_POST);
  
  global $ID_USER;
  $ID_USER = $value['ID_USER'];
  
  home();
  
  return;

} // connect()

/**
 * Arrêt de la connexion
 *
 * @return none
 */
function deconnect()
{
  // Redirection vers la page d'accueil
  header('Location: ../Php');
  
  return;

} // deconnect()

/**
 * Affichage du tableau des documents
 * pour un utilisateur donné
 *
 * @return none
 */
function liste()
{
  global $ID_USER;
  
  $mdocuments = new MDocuments($ID_USER);
  $data_doc = $mdocuments->SelectUserAll();

  global $content; 
  $content['title'] = 'Liste';
  $content['class'] = 'VDocuments';
  $content['method'] = 'showList';
  $content['arg'] = $data_doc;
  
  return;
    
} // liste()

/**
 * Affichage d'un document
 * pour un utilisateur donné
 *
 * @return none
 */
function doc()
{
  global $ID_USER;
  
  $mdocuments = new MDocuments($ID_USER, $_GET['ID_DOC']);
  $data_doc = $mdocuments->Select();
  
  global $content; 
  $content['title'] = 'Document';
  $content['class'] = 'VDocuments';
  $content['method'] = 'showDoc';
  $content['arg'] = $data_doc;
  
  return;
  
} // doc()

/**
 * Affichage du formulaire pour un document
 *
 * @return none
 */
function form($type)
{
  global $ID_USER;
  
  $data_doc = '';
  if (isset($_GET['ID_DOC']))
  {
    $mdocuments = new MDocuments($ID_USER, $_GET['ID_DOC']);
    $data_doc = $mdocuments->Select();
  }
  
  global $content; 
  $content['title'] = 'Nouveau';
  $content['class'] = 'VDocuments';
  $content['method'] = 'showForm';
  $content['arg'] = $data_doc;
  
  return;
  
} // form($type)

/**
 * Modifie les données dans la table DOCUMENTS
 * @param string type de modification : insert, update ou delete
 *
 * @return none
 */
function modify($type)
{
  global $ID_USER;
  
  $id_doc = isset($_REQUEST['ID_DOC']) ? $_REQUEST['ID_DOC'] : '';
  
  $mdocuments = new MDocuments($ID_USER, $id_doc);
  if ($_POST) $mdocuments->SetValue($_POST);
  $mdocuments->Modify($type);
  
  liste();
  
  return;
  
} // modify($type)
?>
