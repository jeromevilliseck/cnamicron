<?php
/**
 * Fichier de classe de type Vue
 * pour les documents
 * @author Christian Bonhomme
 * @version 1.0
 * @package Sécurité
 */

class VDocuments
{
  /**
   * Constructeur de la classe VDocuments
   * @access public
   *        
   * @return none
   */
  public function __construct(){}
  
  /**
   * Destructeur de la classe VDocuments
   * @access public
   *
   * @return none
   */
  public function __destruct(){}
  
  /**
   * Affichage d'un document
   * @access public
   * @param array données du document
   *
   * @return none
   */
  public function showDoc($_value)
  {
   echo <<<HERE
<h1>{$_value['TITRE']}</h1>
<p>{$_value['TEXTE']}</p>
HERE;
   
   return;
            
  } // showDoc($_value)
  
  /**
   * Affichage du tableau des documents
   * @access public
   * @param array données des documents
   *
   * @return none
   */
  public function showList($_the_values)
  {
    global $ID_USER;
    
    $tr = '';
    foreach($_the_values as $val)
    {
      $tr .= '<tr><td><a href="../Php/index.php?EX=form_update&amp;ID_DOC='.$val['ID_DOC'].'&amp;ID_USER='.$ID_USER.'">'.$val['TITRE'].'</a></td><td>'.$val['TEXTE'].'</td></tr>';
    }
    
    echo <<<HERE
<table>
 <caption>Documents</caption>
 <thead>
  <tr>
   <th>Titre</th>
   <th>Texte</th>
  </tr>
 </thead>
<tbody>
 $tr
</tbody>
</table>
HERE;
    
    return;
            
  } // showList($_the_values)
  
  /**
   * Affichage du formulaire pour un  document
   * @access public
   * @param array données du documents
   *
   * @return none
   */
  public function showForm($_value)
  {
    global $ID_USER;
    
    if ($_value)
    {
      $EX = 'update';
      $id_doc = $_value['ID_DOC'];
      $titre = $_value['TITRE'];
      $texte = $_value['TEXTE'];
      $submit = 'Modifier';
      $delete = '<a href="../Php/index.php?EX=delete&amp;ID_DOC='.$id_doc.'&amp;ID_USER='.$ID_USER.'"><button type="button">Supprimer</button></a>';
    }
    else
    {
      $EX = 'insert';
      $id_doc = '';
      $titre = '';
      $texte = '';
      $submit = 'Envoyer';
      $delete= '';
    }
        
    echo <<<HERE
<form id="doc" action="../Php/index.php" method="post">
 <fieldset>
  <legend>Document</legend>
  <input type="hidden" name="EX" value="$EX" />
  <input type="hidden" name="ID_DOC" value="$id_doc" />
  <input type="hidden" name="ID_USER" value="$ID_USER" />
  <p>
   <label for="titre">Titre</label>
   <input id="titre" class="required" name="TITRE" value="$titre" size="15" maxlength="100" />
  </p>
  <p>
   <label for="texte">Texte</label>
   <textarea id="texte" class="required" name="TEXTE" rows="5" cols="15" maxlength="1000">$texte</textarea>
  </p>
  <p class="submit">
   <input type="submit" value="$submit" />
   $delete
  </p>
 </fieldset>
</form>
HERE;
    
    return;

  } // showForm($_value)
 
} // VDocuments
?>