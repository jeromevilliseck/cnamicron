<?php
/**
 * Fichier de classe de type Vue
 * pour l'affichage de la navigation
 * @author Christian Bonhomme
 * @version 1.0
 * @package Sécurité
 */
 
class VNav
{
  /**
   * Constructeur de la classe VNav
   * @access public
   *        
   * @return none
   */
  public function __construct(){}
  
  /**
   * Destructeur de la classe VNav
   * @access public
   *
   * @return none
   */
  public function __destruct(){}
  
  /**
   * Affichage de la navigation
   * @access public
   *
   * @return none
   */
  public function showNav()
  {
    global $ID_USER;
    
    if ($ID_USER)
    {
      // Récupère tous les documents d'un utilisateur
      $mdocuments = new MDocuments((int)$ID_USER);
      $the_values = $mdocuments->SelectUserAll();
        
      // Crée les différents boutons pour l'affichage des documents
      $li = '';
      foreach ($the_values as $val)
      {
        $li .= '<li><a href="../Php/index.php?EX=doc&amp;ID_DOC='.$val['ID_DOC'].'&amp;ID_USER='.$ID_USER.'">'.$val['TITRE'].'</a></li>';
      }
      $li .= '<li><a href="../Php/index.php?EX=liste&amp;ID_USER='.$ID_USER.'">Liste</a></li>';
      $li .= '<li><a href="../Php/index.php?EX=form_insert&amp;ID_USER='.$ID_USER.'">Nouveau</a></li>';
      $li .= '<li><a href="../Php/index.php?EX=deconnect">Au revoir</a></li>';
      
    }
    else
    {
      $li = '<li><a href="../Php/index.php?EX=admin">Connexion</a></li>';
    }
      
    // Affiche la navigation
    echo <<<HERE
      <h1 id="logo" title="Logo"><a href="../Php/index.php?EX=home&amp;ID_USER=$ID_USER">Logo</a></h1>
      <ol id="menu">
       $li
      </ol>
HERE;
    
    return;
    
  } // showNav()
  
} // VNav
?>