<?php
/**
 * Contrôleur
 * @author Christian Bonhomme
 * @version 1.0
 * @package MVC
 */

// Variable de contrôle
$EX = isset ($_REQUEST['EX']) ? $_REQUEST['EX'] : 'home';

// Contrôleur
switch ($EX)
{
  case 'home'     : $val = 'd\'accueil';
                    break;
  case 'calcul'   : $val = 'de la calculatrice';
                    break;
  case 'peintres' : $val = 'des peintres';
                    break;
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<meta charset="utf-8" />
<title>MVC</title>
</head>

<body>
<header>
 <a href="../Php/index.php?EX=home">Accueil</a>
 <a href="../Php/index.php?EX=calcul">Calculatrice</a>
 <a href="../Php/index.php?EX=peintres">Peintres</a>
</header>

<div id="content">
 <p>Ceci est la page <?=$val?>.</p>
</div>
</body>
</html>
