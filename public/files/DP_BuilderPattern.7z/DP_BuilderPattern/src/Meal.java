import java.util.ArrayList;
import java.util.List;

public class Meal {
	private List<Item> items = new ArrayList<Item>();
	
	public void addItem(Item item) {
		items.add(item);
	}
	
	public float getCost() { // Compteur de price -> incremente le prix a chaque ajout d'objet
		float cost = 0.0f;
		for (Item item : items) {
			cost += item.price();
		}
		return cost;
	}
	
	public void showItems() {// Boucle de type "foreach" qui passe sur chaque objet et appelle ses
								// caractéristiques
		for (Item item : items) {
			System.out.print("Item : " + item.name());
			System.out.print(", Packing : " + item.packing().pack()); // Spécificité
			System.out.println(", Price : " + item.price());
		}
	}
}