public class Wrapper implements Packing {
	public String pack() {
		return "Wrapper";
	}
}