<?php
CarFactory::getCar();
