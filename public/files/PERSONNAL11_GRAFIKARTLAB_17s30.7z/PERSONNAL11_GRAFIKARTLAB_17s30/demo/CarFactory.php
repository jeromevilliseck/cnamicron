<?php
class CarFactory{

  public static function getCar($type){ //en parametre le type de voiture que l'on souhaite créer
    $type = ucfirst($type);
    $class_name = 'Car'.$type; //COncatenation avec le type passé en paramètre
    return new $class_name; //Retourne un nouvel objet
  }

}
