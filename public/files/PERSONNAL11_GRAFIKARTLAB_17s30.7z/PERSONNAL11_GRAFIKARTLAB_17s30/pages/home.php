<!--Si je veux afficher la liste de mes catégories a droite-->
<div class="row">

  <div class="col-sm-8"> <!-- dans cette classe div le listage principal des articles-->
    <?php
    foreach (\App\Table\Article::getLast() as $post): //$db à été modifié par un appel statique -> on peut se connecter à la bdd sans se soucier de la portée de variable pour un objet $db qui était préalablement utilisé
    ?>

    <!--Meme si la méthode article de getLast n'est définie que dans le parent Table, l'utilisation de static:: au lieu de self:: permet bien de faire reference a article (classe enfant) et non table (classe parent)-->

    <?php var_dump($post) ?>

      <li>
        <a href="<?= $post->url; ?>"> <!--ici c'est une méthode qui est utilisée pas un attribut via la méthode magique __get de la classe parent Table-->
        <?= $post->titre; ?></a> <!-- grace aux modifications dans la classe Article avec l'insertion de l'alias dans la requête sql de la fonction getLast  on peut désormais utiliser un couple objet-indice $post->categorie-->
        <p>
          <em><?= $post->categorie; ?></em>
        </p>
      </li>

        <p>
          <?= $post->extrait; ?>
       </p>

    <?php
    endforeach;
    ?>
  </div>

  <div class="col-sm-4">
    <ul>
    <?php
    foreach (\App\Table\Categorie::all() as $categorie): //$db à été modifié par un appel statique -> on peut se connecter à la bdd sans se soucier de la portée de variable pour un objet $db qui était préalablement utilisé
    ?>

<?php var_dump($categorie) ?>

    <li>
      <a href="<? $categorie->url; ?>">
        <?= $categorie->titre; ?></a></li>
    </li>
    <?php
    endforeach;
    ?>
    </ul>
  </div>
</div>

<!--
$post->url          METHODE
$post->titre        ATTRIBUT SQL
$post->categorie    ATTRIBUT SQL
$post->extrait      ATTRIBUT SQL

$categorie->url     METHODE
$categorie->titre   ATTRIBUT SQL
-->
