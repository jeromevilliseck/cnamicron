<?php
$article = \App\Table\Article::find($_GET['id']);

var_dump($article);
?>
