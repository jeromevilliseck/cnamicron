<?php
namespace App\Table;

class Table {
    protected $table;
    protected $db;

    //INJECTION DE DEPENDANCE
    //Je passe en paramètre aux tables une connexion a la base de données lors des instanciation
    public function __construct(\App\Database\Database $db) { //On précise le type de la variable recherchée en paramètre -> pour travailler j'ai besoin de passer en paramètre la base de donnée que je stocke au niveau de l'instance
                                //Attention on précise bien que l'on veut en paramètre la classe Database et avec l'heritage ça marche aussi
      $this->db = $db;
        if (is_null($this->$table)) {
            $parts        = explode('\\', get_class($this));
            $class_name   = end($parts);
            $this->$table = strtolower(str_replace('Table', '', $class_name));
        }
    }

    //METHODE HERITEE
    //Grace a l'injection de dépendance on a directement la base de donnée en faisant $this->db->query
    public function all(){
      return $this->db->query('SELECT * FROM articles');
    }

    /*PROBLEME
    * Les clases communiquent les unes avec les autres
    * ex la classe table communique avec la classe Database
    * si je veux dissocier les classes les unes des autres cele est génant
    * pour que la fonction query fonctionne j'ai besoin de la BDD, je ne peux pas utiliser une classe sans une autre
    * solution INJECTION DE DEPENDANCES
    * car les classe tables ont toujours besoin de faire des requetes
    */

    /*INJECTION DE DEPENDANCES
    * si une classe a besoin d'une autre, il faudra l'injecter au moment :
    * ->de son constructeur
    * ->de l'appel des méthodes
    */
}
