<?php
namespace App\Table;

class CategoriesTable extends Table{
}
