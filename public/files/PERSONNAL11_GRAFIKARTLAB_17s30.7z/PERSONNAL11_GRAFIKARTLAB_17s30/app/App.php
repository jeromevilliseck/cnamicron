<?php
namespace App;

class App {

    public $title = "Mon super site";
    private static $_instance;
    private $db_instance;

    //SINGLETON
    public static function getInstance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new App();
        }
        return self::$_instance;
    }

    public function getDb() {
        if (is_null($this->db_instance)) {
            $config            = Config::getInstance(); //Création d'un objet à partir du singleton de la classe Config
            $this->db_instance = new Database\MysqlDatabase($config->get('db_name'), $config->get('db_user'), $config->get('db_pass'), $config->get('db_host')); //Voir la classe Config.php pour comprendre le focntionnement de ces getters qui font appel au indices d'un tableau obtenus via le constructeur
            //Ici il faut bien modifier le namespace pour lui préciser le chemin ici Database\..vu que je suis deja dans le app
        }
        return $this->db_instance;
    }

    public function getTable($name) {
        $class_name = '\\App\\Table\\' . ucfirst($name) . 'Table';
        return new $class_name($this->getDb()); //This->getDb() est IMPORTANT on passe en parametre lors de la creation de l'objet la connexion a la base de données
        //INJECTION DE DEPENDANCE -> on a la creation d'un objet de type Table (parent ou enfant) avec en paramètre la connexion a la bdd
    }

}
