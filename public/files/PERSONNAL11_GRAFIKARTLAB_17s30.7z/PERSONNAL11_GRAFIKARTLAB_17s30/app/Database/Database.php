<?php

namespace App\Database;

class Database{
}

/*Pourquoi utiliser le mécanisme de l'héritage sur Database ? parce que si je change de client pour SQL
* par exemple MongoDB
* je créerais une classe MongoDbDatabase qui héritera de Database
*/
