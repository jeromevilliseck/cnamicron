<?php

namespace App;


class Config {

    private $settings = []; //Tableau vide qui va prendre les paramètres pour se connecter a la base de données
    private static $_instance; //Le underscore permet de distinguer les variables statiques pour grafikart

    //SINGLETON
    public static function getInstance() { //Ce getter créer une nouvel instance à son appel depuis un objet
        if (is_null(self::$_instance)) { //seulement si ma variable $_instance est nulle (ne contient pas d'objet), je l'instancie
            self::$_instance = new Config();
        }
        return self::$_instance; //Sinon si elle contient deja un objet je la retourne seuelment sans aucune nouvelle affectation
    }

    public function __construct() {
        $this->settings = require dirname(__DIR__) . '/config/config.php'; //Dirname permet de remonter d'un cran dans une arborsence, __DIR__ cible le repertoire courant
    }
    // Le tableau a pris les associations clés / valeurs du fichier config/config.php

    //Accesseur des élements du tableau avec contrôle de l'existence de la clé passée en paramètre
    public function get($key) {
        if (!isset($this->settings[$key])) {
            return null;
        }
        return $this->settings[$key]; //ne pas oublier le $this pour cibler les attributs de la classe (->ce tableau)
    }

}
