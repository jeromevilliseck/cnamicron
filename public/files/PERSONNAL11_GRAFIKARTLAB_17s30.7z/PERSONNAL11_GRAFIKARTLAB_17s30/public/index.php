<?php
session_start(); //Démarrage d'une session d'utilisation
require '../app/Autoloader.php';
App\Autoloader::register();


$app = App\App::getInstance(); //On crée un objet de type App

//Les 2 lignes ci dessous peuvent désormais être géré dans le factory
//$db = new App\Database('blog');
//$posts = new App\Table\PostsTable($db);

$posts = $app->getTable('Posts');
var_dump($posts->all());
