<?php

return array( //Tableau qui retourne les clés et les indexes

    "db_user" => "", //on peut utiliser => au lieu de ->
    "db_pass" => "",
    "db_host" => "",
    "db_name" => ""

);
