<?php
/**
 * Contrôleur
 * @author Christian Bonhomme
 * @version 1.0
 * @package MVC
 */

// Inclusion des constantes et des fonctions de l'application
// en particulier l'Autoload
require('../Inc/require.inc.php');

// Variable de contrôle
$EX = isset ($_REQUEST['EX']) ? $_REQUEST['EX'] : 'home';

// Contrôleur
switch ($EX)
{
  case 'home'     : home();
                    break;
  case 'calcul'   : calcul();
                    break;
  case 'peintres' : peintres();
                    break;
}

// Mise en page
require('../View/layout.view.php');

/**
 *  Affichage de la page d'accueil
 *  
 *  @return none
 */
function home()
{
  global $content;
  
  $content['title'] = 'Accueil';
  $content['class'] = 'VHtml';
  $content['method'] = 'showHtml';
  $content['arg'] = '../Html/home.html';
  
  return;
  
} // home()

/**
 *  Affichage de la page calcul
 *  
 *  @return none
 */
function calcul()
{  
  global $content;
  
  $content['title'] = 'Calculatrice';
  $content['class'] = 'VHtml';
  $content['method'] = 'showHtml';
  $content['arg'] = '../Html/calcul.html';

  return;
  
} // calcul()

/**
 *  Affichage des peintres
 *  
 *  @return none
 */
function peintres()
{
  global $content;
  
  $content['title'] = 'Peintres';
  $content['class'] = 'VText';
  $content['method'] = 'showText';
  $content['arg'] = 'des peintres';
  
  return;
  
} // peintres()
?>
