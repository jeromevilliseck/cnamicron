<?php
/**
 * Fichier de mise en page
 * @author Christian Bonhomme
 * @version 1.0
 * @package MVC
 */

global $content;
$vheader = new VHeader();
$vcontent = new $content['class']();
?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<meta charset="utf-8" />
<title><?=$content['title']?></title>
</head>

<body>
<header>
<?php $vheader->showHeader(); ?>
</header>

<div id="content">
<?php $vcontent->$content['method']($content['arg']); ?>
</div>
</body>
</html>
