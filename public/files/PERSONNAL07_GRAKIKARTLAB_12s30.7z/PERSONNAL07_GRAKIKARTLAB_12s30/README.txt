Aller dans la classe
Database.php -> mettre vos informations de connexion à la bdd
inddex.php -> Dans l'objet new database -> Le nom de votre base de donnée a renseigner en paramètres