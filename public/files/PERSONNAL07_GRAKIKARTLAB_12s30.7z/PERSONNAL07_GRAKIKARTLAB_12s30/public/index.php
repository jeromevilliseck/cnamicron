<?php
require '../app/Autoloader.php';
App\Autoloader::register();

//Variable de contrôle
if (isset($_GET['p'])){
  $p = $_GET['p'];
} else {
  $p = 'home';
}

//Initialisation des objets
$db = new App\Database(''); //Création de l'objet de type Database dans le fichier principal

//Contrôleur
ob_start();
if ($p === 'home'){
  require '../pages/home.php';
} elseif ($p === 'article') { //dans la page home reperez le <?= $post->url; ? > qui vaut dans la classe Article return 'index.php?p=article&id=' . $this->id;
  require '../pages/article.php'; //p et id sont les indices d'un TABLEAU ASSOCIATIF RAPPEL
}
$content = ob_get_clean();

  require '../pages/templates/default.php';

?>
