<ul> <!-- les ul sont en dehors de la boucle-->
<?php foreach ($db->query('SELECT * FROM GRAFIKART', 'App\Table\Article') as $post): ?> <!--Début de la boucle et stockage de la requête (appel a la fonction query de la classe Database), qui donne un objet dans post   +   Passage de la classe Articles en second paramètre comme j'utilise FETCH_CLASS et non plus FETCH_OBJ-->

  <li>
    <a href="<?= $post->url; ?>"> <!-- Mise des titres dans une balise lien qui pointe vers le tuple à travers l'utilisation de $post->id + via la fonction getURL dans la classe article -->
    <?= $post->titre; ?></a> <!--Récupération des valeurs de l'attribut SQL titre à travers l'objet $post-->
  </li>

    <p>
      <?= $post->extrait; ?> <!-- Récupération des valeurs de l'attribut contenu -> aller voir la fonction dans la classe -->
    </p>

<?php endforeach; ?>
</ul>
