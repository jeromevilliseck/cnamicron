<?php //Création de la page article quand on clique sur
$post = $db->prepare('SELECT * FROM GRAFIKART WHERE id=?', [$_GET['id']], 'App\Table\Article'); //plutôt que de faire un query on fait ici une requête préparée qui sécurise le code et évite les injections SQL
//il faut egalement écrire la fonction prepare() dans la classe Database, et utiliser en 3eme parametre le nom de la classe a utiliser qui est Articles ici
?> <!--On utilise l'id en paramètre-->

<h2><?= $post->titre; ?></h2>  <!-- Ne pas oublier le point virgule a la fin de chaque attribut-->
<p>
  <?= $post->contenu; ?>
</p>
