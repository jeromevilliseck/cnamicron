<?php //Création de la page article quand on clique sur le lien avec l'id
$post = $db->prepare('SELECT * FROM GRAFIKART WHERE id=?', [$_GET['id']], '\App\Table\Article', true); //plutôt que de faire un query on fait ici une requête préparée qui sécurise le code et évite les injections SQL
?> <!--On utilise l'id en paramètre 2, en paramètre 3 la classe Article-->

<h2><?= $post->titre; ?></h2>  <!-- Ne pas oublier le point virgule a la fin de chaque attribut-->
<p>
  <?= $post->contenu; ?>
</p>
