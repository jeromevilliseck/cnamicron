<?php
namespace App\Table;

class Article{//Plutôt que d'initialiser une classe vide doit intialiser une instance de Article

  //Il ne faut pas utiliser ce type de fonction magique ci-dessous souvent car on perd en lisibilité, on cache l'accès aux méthodes directes pour l'uilisateur

  public function __get($key){ //Application de la fonction magique __get -> dès que l'on va appeler dans une instance(objet) une fonction que la classe article n'a pas, il appelle cette fonction
      $method = 'get' . ucfirst($key); //$method contiendra getUrl si je passe objet->url comme méthode (ucfirst mets la première lettre en majuscule)
      $this->$key = $this->$method(); //IMPORTANT prenez garde a la syntaxe particuliere $this->$methode() il y a 2 $ qui en fait cela remplace automatiquement $method et fait comme si on appelait la fonction
      //Les 2$ pour les this signifient qu'on cible non pas une variable ou méthode de la classe, mais une variable ou méthode de LA METHODE en cours
      return $this->$key; //on retourne ainsi la chaine concaténée, ce qui fait qu'on a amélioré la syntaxe du coup on peut créer plein de getter qui seront appelés automatiquement en donnant juste la syntaxe instance->methode et non plus instance->getMethode
  }

  public function getUrl(){
    return 'index.php?p=article&id=' . $this->id; //this signifie un article, l'id de cet article pointé
  }

  public function getExtrait(){
    $html = '<p>' . substr($this->contenu, 0, 100) . '...</p>'; //cela retourne la valeur dans l'attribut contenu de cet article
                          //second parametre indique ou on commence la chaîne de caractères, le troisième paramètre ou on arrête la chaine de caractères
    $html .= '<p><a href="'.$this->getURL().'">Voir la suite</a></p>'; //IMPORTANT -> le .= signifie qu'on rajoute la chaîne de caractères à la chaine précédente
                            //Le this->getURL designe applique la fonction de la classe courante
    return $html; //On return le code html concaténé
  }

}
