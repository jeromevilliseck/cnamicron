public class FactoryPatternDemo {
	public static void main(String[] args) {
		// creation d'un objet de type factory
		ShapeFactory shapeFactory = new ShapeFactory();
		
		// utilisation de la methode de l'objet factory pour creer un objet dont le type
		// va varier selon l'argument passe en parametre -> le type de l'objet est celui
		// de l'interface
		Shape shape1 = shapeFactory.getShape("CIRCLE");
		
		// appel de la methode commune draw de l'interface mais qui a ete redefinie dans
		// chaque classe
		shape1.draw();
		// idem pour creer d'autres objet meme demarche
		Shape shape2 = shapeFactory.getShape("RECTANGLE");
		shape2.draw();
		Shape shape3 = shapeFactory.getShape("SQUARE");
		shape3.draw();
	}
}