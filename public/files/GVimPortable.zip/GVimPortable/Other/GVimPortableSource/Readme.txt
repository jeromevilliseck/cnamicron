GVim Portable README File
=========================

Prerequisites
-------------
GVim Portable is a Microsoft Windows Application, therefore you need to
have this operating system.

Obtaining GVim Portable
-----------------------
The latest GVim Portable version and online documentation can be found at
http://portablegvim.sourceforge.net/[] and at the SourceForge
http://sourceforge.net/projects/portablegvim/[].

COPYING
-------
Copyright (C) 2006-2007 Roland Kammerer. Free use of this software
is granted under the terms of the GNU General Public License (GPL).

