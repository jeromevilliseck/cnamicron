<h1>Je suis la page d'accueil</h1>

<p><a href="index.php?p=single">aller a page single</a></p><!--Important petit lien pour aller à la single noter le tableau associatif-->
<!-- l'indice est p
 la valeur de l'indice est single -->
