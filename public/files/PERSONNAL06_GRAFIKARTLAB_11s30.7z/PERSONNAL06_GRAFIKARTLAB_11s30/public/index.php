<?php
require '../app/Autoloader.php';
App\Autoloader::register(); //Je dois placer avant le namespace car je n'ai pas fait de use ici

//Variable de contrôle
if (isset($_GET['p'])){ //Utilisation d'un tableau associatif avec la méthode get
  $p = $_GET['p'];
} else {
  $p = 'home'; //Si la variable $_GET n'existe pas (controle assuré par isset) alors on $p = home, appelrea la page d'accueil
}

//Contrôleur
ob_start(); //Permet d'indiquer à Php que tout ce qui sera affiché sera désormais stocké dans une variable
if ($p === 'home'){ //les 3 égal vont une vérification stricte en valeur et EN TYPE (ici chaine de caractères)
  require '../pages/home.php'; //On inclus la page home
} elseif ($p === 'single') {
  require '../pages/single.php'; //On gère ainsi tout les cas
}
$content = ob_get_clean(); //Les requires vont ainsi ête affiché mais ATTENTION ! il vont être stocké dans la variable $content

//Affichage du layout
  require '../pages/templates/default.php'//Il suffit ensuite de require le layout pour lui faire afficher le contenu + le contenu de la variable $content

?>
