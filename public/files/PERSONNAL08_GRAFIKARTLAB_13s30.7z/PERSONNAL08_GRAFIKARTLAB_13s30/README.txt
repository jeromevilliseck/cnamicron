Aller dans la classe
App.php -> Mettre les informations relative à votre base de données