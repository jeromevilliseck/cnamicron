<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?= App\App::getTitle(); ?></title> <!-- j'utilise un getter statique de la classe App pour récupérer le titre de la page web NE PAS OUBLIER LE NAMESPACE-->

    <!-- Bootstrap core CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Custom styles for this template -->
    
  </head>

  <body>

    <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="#">Navbar</a>
    </nav>

    <main role="main" class="container">

      <div class="starter-template" style="padding-top:100px;">
        <?= $content; ?> <!--Affichage du contenu des pages SYNTAXE ABREGEE -> Il faut dans index.php pour chaque cas gérer un $content qui prend une valeur différente-->
      </div>

    </main><!-- /.container -->

  </body>
</html>
