<?php
namespace App;
use \PDO; //OBLIGATOIRE car comme on utilise des namespace en utilisant uniquement PDO le porjet n'arrivera pas a aller chercher la classe prédéfinie il faut lui indiquer par cette antislash que c'est une classe prédéfinie à la racine
/**
* Class Database
* @package App
*/

class Database{
  private $db_name;
  private $db_user;
  private $db_pass;
  private $db_host;
  private $pdo;

  public function __construct($db_name, $db_user, $db_pass, $db_host){
    $this->db_name = $db_name;
    $this->db_user = $db_user;
    $this->db_pass = $db_pass;
    $this->db_host = $db_host;
  }

  private function getPDO(){
    if($pdo === NULL){
      $pdo = new PDO($this->db_name, $this->db_user, $this->db_pass);
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $this->pdo = $pdo;
    }
    return $pdo;
  }

  public function query($statement, $class_name, $one = false){ //En premier paramètre un $statement (la requête SQL), en second paramètre la classe à utiliser
    $result = $this->getPDO()->query($statement);
    $result->setFetchMode(PDO::FETCH_CLASS, $class_name); //On utilise plus FETCH_OBJ mais FETCH_CLASS, et en second paramètre on précise la classe à utiliser lors de l'appel de la fonction
    if ($one) { //Cette condition permet en cas de présence d'un 4ème paramètre d'utiliser la méthode fetch et non pas fetchall car pour l'affichage d'un article fetchall ne peut pas retourner sur $post un seul tuple, on ne peut utiliser fetchall qu'a travers un foreach dans les vues
    $datas = $result->fetch();
    } else {
    $datas = $result->fetchAll();
    }
    return $datas;
  }

  public function prepare($statement, $values, $class_name, $one = false){ //il y a un attribut supplémentaire par rapport à un query standard
    $result = $this->getPDO()->prepare($statement); //On prépare notre requête
    $result->execute($values);//on passe en paramètre les attributs, et on execute, ATTENTION a ce stade les résultats ne sont pas récupérés
    $result->setFetchMode(PDO::FETCH_CLASS, $class_name); //permet de passer l'objet $result en mode fetch class et ensuite de pouvoir appliquer sans paramètre un fetch ou un fetch all
    if ($one) { //Cette condition permet en cas de présence d'un 4ème paramètre d'utiliser la méthode fetch et non pas fetchall car pour l'affichage d'un article fetchall ne peut pas retourner sur $post un seul tuple, on ne peut utiliser fetchall qu'a travers un foreach dans les vues
    $datas = $result->fetch();
    } else {
    $datas = $result->fetchAll();
    }
    return $datas;
  }
}
