<?php
namespace App;

class App{

  const DB_NAME = '';
  const DB_USER = '';
  const DB_PASS = '';
  const DB_HOST = '';

  private static $database; //Variable statique

  private static $title = "Mon super site";

  public static function getDb(){
    if (self::$database === null){ //Instanciation uniquement si l'objet est null
    self::$database = new Database(self::DB_NAME, self::DB_USER, self::DB_PASS, self::DB_HOST); //self:: equivaut a this sur une méthode statique
    } //Pas besoin de preciser le namespace dans une instanciation dans les classes du meme namespace lorsque l'on marque les namespace
    return self::$database;
    //
  }

  public static function notFound(){
    header("HTTP/1.0 404 Not Found");
    header('Location:index.php?p=404'); //On le renvoie vers une page 404
  }

  //GETTERS ET SETTERS pour le titre de la page
  public static function getTitle(){
    return self::$title;
  }

  public static function setTitle($title){
    self::$title = $title . ' | ' . self::$title; //La concatenation permet de passer les titres en chaine dans l'onglet web
  }




}
