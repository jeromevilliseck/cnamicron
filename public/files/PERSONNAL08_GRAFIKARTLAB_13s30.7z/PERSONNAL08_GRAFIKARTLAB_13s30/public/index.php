<?php
require '../app/Autoloader.php';
App\Autoloader::register();

//Variable de contrôle
if (isset($_GET['p'])){
  $p = $_GET['p'];
} else {
  $p = 'home';
}

//Initialisation des objets -> Ne plus créer d'objet, utiliser à la place une classe statique
//$db = new App\Database('mysql:host=fdb16.awardspace.com;dbname=2357899_cnam'); //Ce n'est pas une méthode recommandée car la portée des variables est assez faible

//Contrôleur
ob_start();
if ($p === 'home'){
  require '../pages/home.php';
} elseif ($p === 'article') { //dans la page home reperez le <?= $post->url; ? > qui vaut dans la classe Article return 'index.php?p=article&id=' . $this->id;
  require '../pages/single.php'; //p et id sont les indices d'un TABLEAU ASSOCIATIF RAPPEL
} elseif ($p === 'categorie') { //dans la page home reperez le <?= $post->url; ? > qui vaut dans la classe Article return 'index.php?p=article&id=' . $this->id;
  require '../pages/categorie.php'; //p et id sont les indices d'un TABLEAU ASSOCIATIF RAPPEL
}
$content = ob_get_clean();

  require '../pages/templates/default.php';

?>
