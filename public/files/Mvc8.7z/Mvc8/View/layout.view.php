<?php
/**
 * Fichier de mise en page
 * @author Christian Bonhomme
 * @version 1.0
 * @package MVC
 */

$vheader = new VHeader();
$vtext = new VText();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<meta charset="utf-8" />
<title>MVC</title>
</head>

<body>
<header>
<?php
 $vheader->showHeader();
?>
</header>

<div id="content">
<?php
 $vtext->showText($val);
?>
</div>
</body>
</html>
