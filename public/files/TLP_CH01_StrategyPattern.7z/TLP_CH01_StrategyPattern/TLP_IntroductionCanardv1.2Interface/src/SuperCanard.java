public abstract class SuperCanard implements Volant, Cancaneur { //EN PLUS IL FAUT DESORMAIS QUE LA SUPER CLASSE HERITE DE TOUTES LES INTERFACES
	//La classe cancaner considérée comme un comportement commun auparavant ne l'est plus considérée. Elle est passée dans une interface mais c'est une mauvaise pratique
	public void nager() {
		System.out.println("flap-flap");
	}
	
	public abstract void afficher(); 
	
	//On considère que seul nage et afficher sont des COMPORTEMENTS COMMUN
	
}