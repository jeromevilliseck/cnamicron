public class Mandarin extends SuperCanard implements Volant {
	@Override
	public void afficher() {
		System.out.println("mandarin");
	}
	
	public void voler() {
		System.out.println("je vole"); 
		//Tres mauvais en maintenabilité -> On a un code ou il faut pour chaque classe fille récrire le crops des méthodes des interface
		//IMAGINER QUE VOUS RAJOUTEZ 30 CLASSES filles à SuperCanard...
	}
	
	public void cancaner() {
		System.out.println("je cancane");
	}
	
}