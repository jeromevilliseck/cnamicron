public class Leurre extends SuperCanard {
	public void afficher() {
		System.out.println("je suis un leurre");
	}
	
	//Ici la classe génère une ERREUR car cancaner et voler etant les méthodes des interface dont la superclasse de leurrre implèmente,
	//ELLE DOIT OBLIGATOIREMENT redéfinir ces méthodes qui ne sont pas définies dans la classe mère.
	//MAUVAISE MAINTENABILITE
}
