public interface Volant {
	public void voler();
}
