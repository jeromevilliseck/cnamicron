public interface Cancaneur {
	public void cancaner();
}
