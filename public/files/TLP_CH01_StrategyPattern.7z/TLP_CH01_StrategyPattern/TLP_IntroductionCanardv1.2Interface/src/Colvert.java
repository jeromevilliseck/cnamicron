public class Colvert extends SuperCanard implements Cancaneur {
	@Override
	public void afficher() {
		System.out.println("colvert");
	}
	
	public void cancaner() {
		System.out.println("coin coin"); //DANGER en cas de MAINTENABILITE -> l'implementation d'un comportement à travers une interface
		//VA nécessiter de décliner et d'écrire pour CHAQUE classe fille les méthodes des interface implémentées
	}
	
	public void voler() {
		System.out.println("je vole");
	}
}