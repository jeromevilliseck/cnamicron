public class Mandarin extends SuperCanard {
	@Override
	public void afficher() {
		System.out.println("mandarin");
	}
	
}