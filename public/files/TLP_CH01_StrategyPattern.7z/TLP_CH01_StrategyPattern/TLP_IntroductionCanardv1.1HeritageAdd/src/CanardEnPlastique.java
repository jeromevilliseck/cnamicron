public class CanardEnPlastique {
	public void voler() {
		System.out.println("je ne vole pas !"); //TRES MAUVAIS ! 
	};
	
	//Un canard en plastique ne vole pas !
	//La redéfinition, même avec un corps vide, d'une méthode est une MAUVAISE SOLUTION
	//La maintenabilité et réutilisabilité est très mauvaise
}
