public class Main {
	public static void main(String[] args) {
		SuperCanard[] canards = new SuperCanard[4];
		
		canards[0] = new Colvert();
		canards[1] = new Mandarin();
		canards[2] = new Colvert();
		canards[3] = new Colvert();
		
		for (SuperCanard varLocale : canards) {
			varLocale.cancaner();
			varLocale.afficher();
		}
	}
}