public class Colvert extends SuperCanard {
	@Override
	public void afficher() {
		System.out.println("colvert");
	}
}