public abstract class SuperCanard {
	//Tous les canards cancanent et nagent. La superclasse gère l'implémentation des méthodes communes
	public void cancaner() { 
		System.out.println("Coin-coin");
	}
	public void nager() {
		System.out.println("flap-flap");
	}
	
	//Je veux ajouter un COMPORTEMENT à toutes mes classes dérivées 
	//ATTENTION ! si jamais je crée ensuite des classes filles, mais que certaines ne doivent pas avoir certains comportements ?
	public void voler() {
		System.out.println("je vole");
	}; //ERREUR -> il va falloir redéfinir dans toutes les classes filles une méthode voler même pour les canards ne volant pas (aller voir la classe CanardEnPlastique)
	//ON A UN HERITAGE FORCE DE TOUT LES COMPORTEMENTS DANS LES SOUS CLASSES
	//RESULTAT TOUT LES CANARDS VOLENT
	
	public abstract void afficher(); 
	
}