
public class NePasVoler implements ComportementVol {
	@Override
	public void voler() {
		// TODO Auto-generated method stub
	}
}
