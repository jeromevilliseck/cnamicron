
public class VolerAvecDesAiles implements ComportementVol {
	public void voler() {
		System.out.println("je vole"); //La méthode est définie par rapport au comportement de la classe spécifié dans son nom
	}
}