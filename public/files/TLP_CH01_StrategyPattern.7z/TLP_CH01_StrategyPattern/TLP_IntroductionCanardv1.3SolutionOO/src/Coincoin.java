
public class Coincoin implements ComportementCancan {
	@Override
	public void cancaner() {
		System.out.println("coin-coin");
	}
}
