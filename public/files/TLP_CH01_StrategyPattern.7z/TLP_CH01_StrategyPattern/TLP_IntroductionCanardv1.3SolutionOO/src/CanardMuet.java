
public class CanardMuet implements ComportementCancan {
	@Override
	public void cancaner() {
		// Ne rien faire c'est un comportement MUET
	}
}
