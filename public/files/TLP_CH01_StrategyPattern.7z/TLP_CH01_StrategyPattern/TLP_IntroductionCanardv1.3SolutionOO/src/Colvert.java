public class Colvert extends SuperCanard{ //PLUS d'IMPLEMENTATION d'INTERFACE
	
	//L'overriding (redéfinition) ne se fait que sur les méthodes abstraites de la super classe (les invariants)
	@Override
	public void afficher() {
		System.out.println("je suis un colvert");
	}

	//REDEFINITION IMPERATIVE DU CONSTRUCTEUR 
	public Colvert() {
		super();
		comportementCancan = new Cancan();
		comportementVol = new VolerAvecDesAiles();
	}
	
}