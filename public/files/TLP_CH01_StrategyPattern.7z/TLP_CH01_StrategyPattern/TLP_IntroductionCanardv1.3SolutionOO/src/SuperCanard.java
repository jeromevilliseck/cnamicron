public abstract class SuperCanard { 	
	//VOLER et CANCANER ont été sorties, extraites de la super classe car ce sont des PARTIES QUI VARIENT
	//-> UN COMPORTEMENT démarrant d'une interface décliné dans des classes qui implémentent
	
	//PUIS écriture de VARIABLES COMPORTEMENTALES qui sont déclarées du type de l'INTERFACE qui gère le comportement
	ComportementVol comportementVol;
	ComportementCancan comportementCancan;
	
	
	//NAGER et AFFICHER sont des COMPORTEMENTS identiques ce sont des PARTIES INVARIANTES ("CONSTANTES" applicatives)
	public void nager() {
		System.out.println("flap-flap");
	}
	
	public abstract void afficher(); 
	
	//ECRITURE DES METHODES qui remplacent les methodes voler() et cancaner() précédentes
	public void effectuerCancan(){
		comportementCancan.cancaner(); //HYPER IMPORTANT -> c'est l'objet de type INTERFACE (qui est le comportement non défini)
									   //qui appelle la méthode, mais la on ne sait pas encore quelle méthode appeler
	}
	
	//LES INSTANCES DE SUPERCANARD DELEGUENT LE COMPORTEMENT AUX OBJETS REFERENCANT UNE VARIABLE DE COMPORTEMENT
	
	/*FONDAMENTAL -> La classe fille va instancier la variable de comportement avec une classe concrête qui implémente l'interface
	*dans son CONSTRUCTEUR
	*/
	
	public void effectuerVol() {
		comportementVol.voler();
	}
	
}