
public class Cancan implements ComportementCancan {
	public void cancaner() {
		System.out.println("je cancane");
	}
}
