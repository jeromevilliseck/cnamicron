
public interface ComportementVol {
	public void voler(); //L'interface contient le comportement global sans le préciser
}
