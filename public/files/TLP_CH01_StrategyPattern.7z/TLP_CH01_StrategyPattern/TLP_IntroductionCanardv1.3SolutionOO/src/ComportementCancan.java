
public interface ComportementCancan {
	public void cancaner();
}
