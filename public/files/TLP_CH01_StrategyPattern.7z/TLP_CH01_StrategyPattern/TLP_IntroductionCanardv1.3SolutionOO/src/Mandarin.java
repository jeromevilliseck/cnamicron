public class Mandarin extends SuperCanard {
	@Override
	public void afficher() {
		System.out.println("mandarin");
	}
	
	//REDEFINITION IMPERATIVE DU CONSTRUCTEUR 
		public Mandarin() {
			super();
			comportementCancan = new Coincoin();
			comportementVol = new VolerAvecDesAiles();
		}
	
}