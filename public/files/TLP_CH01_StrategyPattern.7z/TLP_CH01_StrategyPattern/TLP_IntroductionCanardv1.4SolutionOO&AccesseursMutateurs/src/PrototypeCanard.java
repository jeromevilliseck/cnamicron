
public class PrototypeCanard extends SuperCanard {
	@Override
	public void afficher() {
		System.out.println("nouveau né ne sachant pas voler");
	}
	
	//CONSTRUCTEUR
	
	public PrototypeCanard() {
		comportementCancan = new Cancan();
		comportementVol = new NePasVoler(); //Pour le moment le comportement défini est de ne pas pouvoir voler
	}
	
	
}
