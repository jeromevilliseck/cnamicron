public abstract class SuperCanard { //	Remarquez qu'il n'y a pas d'implémentation dans la super classe
	ComportementVol comportementVol;
	ComportementCancan comportementCancan;
	
	public void nager() {
		System.out.println("flap-flap");
	}
	
	public abstract void afficher(); 
	
	public void effectuerCancan(){
		comportementCancan.cancaner(); 
	}
	
	public void effectuerVol() {
		comportementVol.voler();
	}
	
	public void setComportementVol(ComportementVol cv) { //PARAMETRE de type INTERFACE (Rappel = un comportement générique)
		comportementVol = cv;
	}
	
	public void setComportementCancan(ComportementCancan cc) {
		comportementCancan = cc;
	}
	
}