public class Main {
	public static void main(String[] args) {
		SuperCanard[] canards = new SuperCanard[4];
		
		canards[0] = new Colvert();
		canards[1] = new Mandarin();
		canards[2] = new Colvert();
		canards[3] = new PrototypeCanard();
		
		for (SuperCanard varLocale : canards) { 
			varLocale.effectuerCancan(); //Ca appelle la méthode de SuperCanard qui dont le comportement varie selon chaque constructeur (colvert, mandarin)
			varLocale.afficher();
			varLocale.effectuerVol(); //c'est le constructeur de chaque objet (les classes fille) qui détermine le comportement pour chaque méthode ISOLEE
		}
		
		canards[3].setComportementVol(new PropulsionAReaction()); //Rédéfinition du comportement à la volée à travers le constructeur
		//de la classe mère -> on passe en argument dans le parametre du mutateur un objet qui dérive de l'interface, on redéfini le
		//comportement , on change le comportement contenu dans la variable d'instance de l'Interface ComportementVol
		
		canards[3].effectuerVol(); //Ceci aurait été impossible avec une implémentation du comportement directement dans la classe dérivée
		
		
	}
}