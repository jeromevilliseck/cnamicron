public abstract class SuperCanard {
	//Tous les canards cancanent et nagent. La superclasse gère l'implémentation des méthodes communes
	public void cancaner() { 
		System.out.println("Coin-coin");
	}
	public void nager() {
		System.out.println("flap-flap");
	}
	
	//Comme tout les sous types de canard ont un aspect différent, la méthode afficher est abstraite.
	public abstract void afficher(); 
	
	//RAPPEL présence du constructeur par défaut par défaut implicite ici
}