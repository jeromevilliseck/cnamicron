public abstract class Forme {
	// Cette classe n'est pas accessible dans une autre classe
	public void test() {
		System.out.println("Je suis une méthode privée");
	}
	
	abstract public double aire();
}
