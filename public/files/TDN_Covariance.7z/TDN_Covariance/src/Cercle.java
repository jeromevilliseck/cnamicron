public class Cercle extends Forme {
	@Override
	public double aire() {
		// TODO Auto-generated method stub
		return 0;
	}
}