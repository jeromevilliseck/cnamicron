public class HeritageTest {
	public static void main(String[] args) {
		Cercle c = new Cercle();
		c.test(); //c.test() n'est accessible que si dans la classe mère abstraite Forme elle est publique
		
		
		//LE CASTING sur LES VARIABLES
		double a = 4;
		System.out.println(a); //Aucun problème un entier est aussi un double
		//par contre il affichera 4.0
		
		//int b = 7.8d; //impossible le double ne rentre pas dans un entier
		int d = (int) 7.8d; //fonctionne ! -> CASTING on a transformé le double en entier
		System.out.println(d);
		
		//Co-variance de variables 
		Forme e = new Cercle(); //Attention un cercle est une Forme (Ring is-a Form), mais une Forme n'est pas un Cercle (Form is-not-a Ring)
		System.out.println(e.aire()); //Va appliquer le méthode aire() de la classe fille
		
		Forme[] tab1 = new Forme[3]; //Attention ce n'est pas une nouvelle instance de la classe Forme mais un tableau de Forme
		
		Forme forme1 = new Cercle();
		Forme forme2 = new Triangle(); //Il faudra bien sur créer les classes filles correpondantes
		Forme forme3 = new Carre();
		
		//Affectation des objet dans le tableau
		tab1[0] = forme1; //Pas de souci je peux stocker dans l'indice 0 une variable de type objet préalablement déclarée 
		//ou bien faire une instanciation directement sur l'indice
		tab1[1] = forme2; //Il faudra bien sur créer les classes filles correpondantes
		tab2[2] = forme3; 
		
		for(Forme f: tab1) { //Pour chaque forme que tu vas trouver au niveau du tableau tab1, affiche moi son aire via sa méthode
			System.out.println(f.aire); //MAGIE ! a chaque passage d'indice dans la boucle la méthode appelée est celle de la classe fille
		}
		
	}
}
