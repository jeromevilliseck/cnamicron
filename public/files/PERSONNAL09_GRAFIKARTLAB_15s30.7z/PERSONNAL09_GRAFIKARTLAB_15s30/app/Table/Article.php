<?php
namespace App\Table;
use App\App; //IMPORTANT

class Article extends Table{ //héritage

    protected static $table = 'articles';

    //rédefinition de la méthode find de la classe table en modifiant la requete sql avec une jointure
    public static function find($id){
        return self::query("
        SELECT A.id, A.titre, A.contenu, A.dates, A.categorie_id, B.id, B.titre as categorie
        FROM articles A, categories B
        WHERE A.id = ?
        ", [$id], true);
    }


    //La méthode getLast() est propre aux ARTICLES et aux CATEGORIES elle n'est pas générique et ne vas pas aller dans une classe parent pour faire de l'héritage

    //Cette fonction remplace App\App::getDb()->query('SELECT * FROM articles', 'App\Table\Article') dans home.php
    public static function getLast(){ //récupère les derniers articles
      //J'ai rajouté une jointure dans la requete pour obtenir les categories, quand une requête sql deviens trop grosse on l'a mets entre double quotes et on retourne à la ligne
      return self::query( //this query cible la methode query() de la classe parent
      "SELECT A.id, A.titre, A.contenu, A.dates, A.categorie_id, B.id, B.titre as categorie FROM articles A, categories B WHERE A.categorie_id = B.id" //L'alias   B.titre as categorie   va permettre de pouvoir appeler une variable nommée categorie sur un objet $post
    ); //__CLASS__ on a dynamiquement ainsi le nom de la classe mais on ne le mets plus a cause de la fonction query qui donne le paramètre automatiquement
    }

    //Methode identique a getLast mais avec rajout d'une condition dans la requête sql qui est le parametre de la fonction
    public static function lastByCategory($categorie_id){
      return self::query( //ATTENTION contrairement a getLast() utiliser query et non prepare
      "SELECT A.id, A.titre, A.contenu, A.dates, A.categorie_id, B.id, B.titre as categorie
      FROM articles A, categories B
      WHERE categorie_id = ?
      "
      , [$categorie_id], __CLASS__); //si je ne veux qu'un seul résultat, je rajoute true
    }

    //Méthode spécifique à chaque classe enfant pas d'héritage
    public function getUrl() {
        return 'index.php?p=article&id=' . $this->id;
    }

    //Précise et dépend des article, catégorie puisque dans le corps on a une appel à une méthode non héritée
    public function getExtrait() {
        $html = '<p>' . substr($this->contenu, 0, 100) . '...</p>';
        $html .= '<p><a href="' . $this->getURL() . '">Voir la suite</a></p>';
        return $html;
    }

}
