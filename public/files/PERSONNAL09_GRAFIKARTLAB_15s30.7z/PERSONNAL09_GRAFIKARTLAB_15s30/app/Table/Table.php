<?php
namespace App\Table;
use App\App; //IMPORTANT

//Classe parent qui contient les methodes __get($key), getUrl(), getExtrait(), dont les enfants Article et categorie vont hériter

class Table { //ATTENTION ne pas oublier que l'on est dans une classe statique

    protected static $table; //a ne pas oublier car la methode all utilise cet attrbut

    //Méthode récupérant le nom de la table de manière dynamique
    /*private static function getTable(){
    *    if (static::$table === null){ //si c'est nul (qu'il n'y a pas déja de valeur) on fait une opétation sinon on retourne on retourne la valeur actuelle
    *      $class_name = explode('\\', get_called_class()); //si vous mettez __CLASS__ il va vous retourner la classe mère App\Table\Table et pas App\Table\Categorie
    *      static::$table = strtolower(end($class_name)) . 's'; //la méthode explode fourni un tableau array, pour récupérer la fin du nom de classe App\Table\Table on utilise la methode end() que l'on englobe dans la méthode string to lower pour passer le resultat obtenu en minuscule, puis on concatene dans notre situation avec un s -> resultat : nom_classe + s
    *    }
    *    return static::$table;
    *}
    */

    //La méthode all est générique puisque la requète SQL peux s'adapter à n'importe quelle classe __CLASS__ changeant le paramètre dynamiquement
    public static function all() { //récupère les categories
        return App::getDb()->query("
        SELECT *
        FROM " . static::$table . "
        " //la table dans la requete est désormais prise dynamiquement grace a self qui pointe une variable statique de la classe en cours
        , get_called_class()); //__CLASS__  on a dynamiquement ainsi le nom de la classe -> on a remplacé par get_called_class() de par la relation d'héritage
    }

    public function __get($key) {
        $method = 'get' . ucfirst($key);
        $this->$key = $this->$method();
        return $this->$key;
    }

    //la fonction find est générique on la place donc dans table (classe mère)
    public static function find($id){
        return static::query("
        SELECT *
        FROM " . static::$table . "
        WHERE id = ?
        ", [$id], true);
        //Dans la requete sql on met id en point d'interrogation
        //En deuxième paramètre on passe l'id
        //En troisième paramètre le nom de la classe a appeler avec get_called_class()
        //En quatrième paramètre si on ne veut qu'un seul résultat, avec true
    } //static::$table() peut etre remplacé par static::getTable() pour faire du LATE STATIC BINDING

    //On va vers du code générique en plaçant la tâche query (faire une requete) dans une fonction
    public static function query($statement, $attributes = null, $one = false){ //le paramètre $one spécifie si on ne récupère qu'un seul id
        if ($attributes) {
        return App::getDb()->prepare($statement, $attributes, get_called_class(), $one);
        } else {
        return App::getDb()->query($statement, get_called_class());
        }
    }

}

/* LATE STATIC BINDING (>= php v5.3)
* Dans la classe nous avons remplacé les self:: par des static:: dans les methodes getTable() et all()
* sinon dans la quand j'utilise un objet instancié avec la classe catégorie et que je
* lui applique la méthode all(),  self::getTable() dans le corps de la méthode va renvoyer Table au lieu de Categorie
*   Limitations de self::
*     Les références statiques à la classe courante, avec self:: ou __CLASS__, sont résolues en utilisant la classe à laquelle appartiennent les fonctions, celle où elles ont été définies :
*     Cela pose un probleme sur une classe qui hérite -> un self:: ou __CLASS__ va alors cibler attribut, methode, classe parent et non la classe enfant
*     C'est le même problème avec __CLASS__ qu'il faut remplacer par get_called_class() dans les methodes qui vont être héritées
*/


/* A RETENIR
* Avec cette façon de concevoir il faut que les noms de classe pour les classes Table soient de même nom que les nom des tables de la base de donnees sql
* sinon il faudra utiliser dans la classe enfant un attribut public (ou protected) static $table = '[nom_de_la_classe sql]'
*/

/*DES QU'IL Y A DES enfants
* static:: pluto que self::
* get_called_class() plutot que __CLASS__
*/
