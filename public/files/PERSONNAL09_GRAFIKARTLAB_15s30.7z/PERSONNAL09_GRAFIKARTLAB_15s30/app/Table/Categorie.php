<?php
namespace App\Table;
use App\App; //IMPORTANT

class Categorie extends Table{ //héritage

  protected static $table = 'categories'; //NORMALEMENT avec le late static on pourrait supprimer cet attribut mais cela ne passe pas sur toutes les versions de php

 //Attention au late static binding ici

  //Méthode spécifique à chaque classe enfant pas d'héritage
  public function getUrl() {
      echo 'index.php?p=categorie&id=' . $this->id;
  }

}
