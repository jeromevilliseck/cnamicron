<?php
namespace App;

class App {

    public $title = "Mon super site";
    private static $_instance;

    //SINGLETON
    public static function getInstance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new App();
        }
        return self::$_instance;
    }

    /*il ne faudra pas oublier de créer (a vous de jouer)
     * la méthode getDB()
     * la méthode notFound()
     * en option les méthode getTitle() et setTitle($title)
     */
    
}
