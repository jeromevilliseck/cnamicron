<?php
use App\Table\Article;
use App\Table\Categorie;


$categorie = Categorie::find($_GET['id']); //Je récupère la catégorie dont l'id est passé en paramètre dans la barre d'adresse
if ($categorie === false){ //Si jamais l'utilisateur rentre dans la barre d'adresse un id qui n'existe pas
  App\App::notFound(); //Appel à un méthode statique de la classe app -> bien retenir la syntaxe pour les namespace
}

$articles = Article::lastByCategory($_GET['id']); //cette fonction prendra en paramètre le nom, l'id de la categorie
$categories = Categorie::all();
var_dump($categorie);

?>

<h1><?= $categorie->titre ?></h1>

<div class="col-sm-8"> <!-- dans cette classe div le listage principal des articles-->
  <?php
  foreach ($articles as $post): //je récupère la liste des articles
  ?>


  <?php var_dump($post) ?>

    <li>
      <a href="<?= $post->url; ?>">
      <?= $post->titre; ?></a>
      <p>
        <em><?= $post->categorie; ?></em>
      </p>
    </li>

      <p>
        <?= $post->extrait; ?>
     </p>

  <?php
  endforeach;
  ?>
</div>

<?php
/* les use placés en debut de fichier permettent la syntaxe
* Categorie::find(....
* au lieu de
* \App\Table\Categorie::find(...
*/
?>
