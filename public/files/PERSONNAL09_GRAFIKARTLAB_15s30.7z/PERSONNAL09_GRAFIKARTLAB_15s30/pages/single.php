<?php
use App\App;
use App\Table\Categorie;
use App\Table\Article;

$post = Article::find($_GET['id']);
if($post === false){
    App::notFound();
}

App::setTitle($post->titre); //Je définit le nom de la page avec l'attribut tite du tuple sql ciblé par l'id

$categorie = Categorie::find($post->categorie_id); //Je recupere la categorie de l'id grace au parametre passé

?>




<h1><?= $post->titre; ?></h1>

<p>
  <em><?= $post->categorie; ?></em> <!-- grace a la jointure dans la fonction find() de article je n'ai plus besoin de
    avoir un objet $categorie que j'appelais en faisant $categorie = Categorie::find($post->categorie_id); pour utilisé cet attribut-->
</p>

<p><?= $post->contenu; ?></p>
