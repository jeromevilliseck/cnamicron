<?php
session_start(); //Démarrage d'une session d'utilisation
require '../app/Autoloader.php';
App\Autoloader::register();

$config = App\Config::getInstance(); //Instanciation via une fonction statique -> du coup utilisation du constructeur puisque cette fonction return un new (objet)

$app        = App\App::getInstance();
$app->title = "titre modifié"; //on modifie l'attribut en direct parce qu'il est public, si il avait été privé il fallait passer par un setter

$app2 = App\App::getInstance(); //via la méthode on récupère ici toujours la même instance unique même si on crée un objet différent
echo $app2->title; //va s'afficher
