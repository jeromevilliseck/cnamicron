<?php
/**
 * Contrôleur
 * @author Christian Bonhomme
 * @version 1.0
 * @package MVC
 */

// Variable de contrôle
$EX = isset ($_REQUEST['EX']) ? $_REQUEST['EX'] : 'home';

// Contrôleur
switch ($EX)
{
  case 'home'     : home();
                    break;
  case 'calcul'   : calcul();
                    break;
  case 'peintres' : peintres();
                    break;
}

// Mise en page
require('../View/layout.view.php');

/**
 *  Affichage de la page d'accueil
 *  
 *  @return none
 */
function home()
{
  global $val;
  
  $val = 'd\'accueil';
  
  return;
  
} // home()

/**
 *  Affichage de la page calcul
 *  
 *  @return none
 */
function calcul()
{  
  global $val;
  
  $val = 'de la calculatrice';

  return;
  
} // calcul()

/**
 *  Affichage des peintres
 *  
 *  @return none
 */
function peintres()
{
  global $val;
  
  $val = 'des peintres';

  return;
  
} // peintres()
?>
