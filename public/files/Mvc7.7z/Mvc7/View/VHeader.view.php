<?php
/**
 * Fichier de classe de type Vue
 * pour l'affichage de l'entête
 * @author Christian Bonhomme
 * @version 1.0
 * @package MVC
 */
 
/**
 * Classe pour l'affichage de la navigation
 */
class VHeader
{
  /**
   * Constructeur de la classe VHtml
   * @access public
   *        
   * @return none
   */
  public function __construct(){}
  
  /**
   * Destructeur de la classe VHtml
   * @access public
   *
   * @return none
   */
  public function __destruct(){}
  
  /**
   * Affichage de l'entête
   * @access public
   *
   * @return none
   */
  public function showHeader()
  {
    echo <<<'NOW'
 <a href="../Php/index.php?EX=home">Accueil</a>
 <a href="../Php/index.php?EX=calcul">Calculatrice</a>
 <a href="../Php/index.php?EX=peintres">Peintres</a>
NOW;
    
    return;
    
  } // showHeader()
  
} // VHeader
?>