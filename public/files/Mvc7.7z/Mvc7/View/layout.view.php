<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<meta charset="utf-8" />
<title>MVC</title>
</head>

<body>
<header>
<?php
 require('../View/VHeader.view.php');
 $vheader = new VHeader();
 $vheader->showHeader();
?>
</header>

<div id="content">
<?php
 require('../View/VText.view.php');
 $vtext = new VText();
 $vtext->showText($val);
?>
</div>
</body>
</html>
