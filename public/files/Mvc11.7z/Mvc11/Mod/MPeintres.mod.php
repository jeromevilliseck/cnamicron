<?php
/**
 * Fichier de classe de type Modèle 
 * pour la lecture et la gestion du fichier peintres.txt
 * @author Christian Bonhomme
 * @version 1.0
 * @package EXO-MOOC
 */
class MPeintres
{
  /**
   * Constructeur de la class MPeintres
   * @access public
   *        
   * @return none
   */
  public function __construct() {}
  
  /**
   * Destructeur de la class MPeintres
   * @access public
   *        
   * @return none
   */
  public function __destruct() {}
  
  /**
   * Récupère les données des lignes du fichier peintres.txt
   * @access public
   *        
   * @return array données des lignes
   */
  public function SelectAll()
  {
    // Lit le fichier dans une chaîne
    $text_peintres = file_get_contents('../Text/peintres.txt');
    
    return $text_peintres;
  
  } // SelectAll()
  
} // MPeintres
?>