<?php
/**
 * Travaux Pratiques : Mvc7
 * Autoload
 * @author Christian Bonhomme
 * @version 1.0
 * @package Mvc7
 */

/**
 * Chargement automatique des class
 * @param string class appelée
 *
 * @return none
 */
function __autoload($class)
{
  switch ($class[0])
  {
    // Inclusion des class de type View
    case 'V' : require_once('../View/'.$class.'.view.php');
               break;
    // Inclusion des class de type Mod
    case 'M' : require_once('../Mod/'.$class.'.mod.php');
               break;
  }
  
  return;

} // __autoload($class)
?>