<?php
/**
 * Fichier de classe de type Vue
 * pour l'affichage des textes
 * @author Christian Bonhomme
 * @version 1.0
 * @package MVC
 */
 
/**
 * Classe pour l'affichage des textes
 */
class VText
{
  /**
   * Constructeur de la classe VHtml
   * @access public
   *        
   * @return none
   */
  public function __construct(){}
  
  /**
   * Destructeur de la classe VHtml
   * @access public
   *        
   * @return none
   */
  public function __destruct(){}
  
  /**
   * Affichage du texte
   * @access public
   * @param string texte à afficher
   *
   * @return none
   */
  public function showText($_text)
  {
    echo "<p>Ceci est la page $_text.</p>";
    
    return;
    
  } // showText($_text)
  
} // VText
?>