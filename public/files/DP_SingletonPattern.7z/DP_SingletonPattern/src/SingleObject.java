public class SingleObject {
	// Creer un objet instancié avec la classe SingleObject
	private static SingleObject instance = new SingleObject();
	
	// Creer un constructeur privé de façon à ce que la classe ne puisse pas être
	// instanciée.
	private SingleObject() {
	}
	
	// Obtenir l'unique objet disponible (accesseur/getter)
	public static SingleObject getInstance() {
		return instance;
	}
	
	// Associer des methodes à l'instance
	public void showMessage() {
		System.out.println("Hello world!");
	}
}