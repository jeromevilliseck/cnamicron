<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<meta charset="utf-8" />
<title>MVC</title>
</head>

<body>
<header>
 <a href="../Php/index.php?EX=home">Accueil</a>
 <a href="../Php/index.php?EX=calcul">Calculatrice</a>
 <a href="../Php/index.php?EX=peintres">Peintres</a>
</header>

<div id="content">
 <p>Ceci est la page <?=$val?>.</p>
</div>
</body>
</html>
