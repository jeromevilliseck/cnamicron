<?php
/**
 * Contrôleur
 * @author Christian Bonhomme
 * @version 1.0
 * @package MVC
 */

// Variable de contrôle
$EX = isset ($_REQUEST['EX']) ? $_REQUEST['EX'] : 'home';

// Contrôleur
switch ($EX)
{
  case 'home'     : $val = 'd\'accueil';
                    break;
  case 'calcul'   : $val = 'de la calculatrice';
                    break;
  case 'peintres' : $val = 'des peintres';
                    break;
}

// Mise en page
require('../View/layout.view.php');
?>
