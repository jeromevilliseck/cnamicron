<?php
session_start(); //Démarrage d'une session d'utilisation
require '../app/Autoloader.php';
App\Autoloader::register();

//instanciation classique penible
// $data = new App\Table\PostsTable() //demande une modification du constructeur en cas d'ajout de paramètres, demande des modification smultiples n'est pas pratique

$app = App\App::getInstance(); //On crée un objet de type App

$posts = $app->getTable('Posts'); //On crée un objet de type PostsTable a partir de l'objet Categories
$posts = $app->getTable('Categories');

//UTILISATION D'UNE FACTORY
var_dump(App\App::getTable('posts'));
var_dump(App\App::getTable('Users'));
var_dump(App\App::getTable('categories'));
