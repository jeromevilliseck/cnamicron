<?php
namespace App\Table;

class PostsTable extends Table{
}
