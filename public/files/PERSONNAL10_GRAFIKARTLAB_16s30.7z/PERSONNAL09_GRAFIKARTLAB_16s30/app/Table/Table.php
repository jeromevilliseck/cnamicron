<?php
namespace App\Table;

class Table {
    protected $table;

    public function __construct() { //Extraire le nom de la table
        if (is_null($this->$table)) { //on peut ainsi redéfinir l'attribut $table au besoin dans les classes filles
            $parts        = explode('\\', get_class($this)); //J'explose avec des antislash, $parts contient les morceaux
            $class_name   = end($parts); //Je recupere le dernier morceau, le dernier element d'un tableau ([1]App    [2]Table     [3]ex : PostsTable)
            $this->$table = strtolower(str_replace('Table', '', $class_name)); //On supprime la partie Table du mot (ex : PostsTable) par du vide ce qui donne Posts, puis strtolower donnera posts
        }
    }
}
