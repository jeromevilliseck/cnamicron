<?php
namespace App\Table;

class UsersTable extends Table{
}
