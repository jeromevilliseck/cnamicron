<?php
namespace App;

class App {

    public $title = "Mon super site";
    private static $_instance;
    private $db_instance;

    //SINGLETON
    public static function getInstance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new App();
        }
        return self::$_instance;
    }

    /*il ne faudra pas oublier de créer (a vous de jouer)
     * la méthode getDB()
     * la méthode notFound()
     * en option les méthode getTitle() et setTitle($title)
     */

    //FACTORY pour les bdd
    public function getDb() {
        if (is_null($this->db_instance)) {
            $config            = Config::getInstance(); //Création d'un objet à partir du singleton de la classe Config
            $this->db_instance = new Database($config->get('db_name'), $config->get('db_user'), $config->get('db_pass'), $config->get('db_host')); //Voir la classe Config.php pour comprendre le focntionnement de ces getters qui font appel au indices d'un tableau obtenus via le constructeur
        }
        return $this->db_instance;
    }

    //FACTORY pour la récupération des tables
    //FACTORY elle peut etre en statique ou non   IMPORTANT en la mettant en non statique on peut ainsi l'appeler sur une instance de la classe app construite avec le singleton
    public function getTable($name) {
        $class_name = '\\App\\Table\\' . ucfirst($name) . 'Table'; //Concatenation avec le mot table passé en paramètre et le namespace en complet ne pas oublier 2\ \\ pour echapper l'antislash
        return new $class_name();
    }

}
