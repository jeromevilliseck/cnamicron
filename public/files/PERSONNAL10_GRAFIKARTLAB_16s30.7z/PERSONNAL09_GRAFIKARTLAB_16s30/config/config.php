<?php

return array( //Tableau qui retourne les clés et les indexes

    "db_user" => "mysql:host=fdb16.awardspace.com;dbname=2357899_cnam", //on peut utiliser => au lieu de ->
    "db_pass" => "2357899_cnam",
    "db_host" => "tpcnam2017",
    "db_name" => "fdb16.awardspace.com"

);
