public class AbstractFactoryPatternDemo {
	public static void main(String[] args) {
		// obtenir une Shape Factory
		AbstractFactory shapeFactory = FactoryProducer.getFactory("SHAPE");
		// obtenir un objet Shape Circle
		Shape shape1 = shapeFactory.getShape("CIRCLE");
		// appeler la méthode de Shape Circle
		shape1.draw();
		// obtenir un objet Shape Rectangle
		Shape shape2 = shapeFactory.getShape("RECTANGLE");
		// appeler la méthode de Shape Rectangle
		shape2.draw();
		// obtenir un objet Shape Square
		Shape shape3 = shapeFactory.getShape("SQUARE");
		// appeler la méthode de Shape Square
		shape3.draw();
		// obtenir une Color Factory
		AbstractFactory colorFactory = FactoryProducer.getFactory("COLOR");
		// obtenir un objet Shape Circle
		Color color1 = colorFactory.getColor("RED");
		// appeler la méthode de Shape Circle
		color1.fill();
		// obtenir un objet Shape Rectangle
		Color color2 = colorFactory.getColor("GREEN");
		// appeler la méthode de Shape Rectangle
		color2.fill();
		// obtenir un objet Shape Square
		Color color3 = colorFactory.getColor("BLUE");
		// appeler la méthode de Shape Square
		color3.fill();
	}
}